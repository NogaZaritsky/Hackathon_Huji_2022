from msilib.schema import Class

