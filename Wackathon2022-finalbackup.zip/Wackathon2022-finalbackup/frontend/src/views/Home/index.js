import React, { useState } from "react";
import BuddyLabel from "../../components/molecules/BuddyLabel/BuddyLabel";
import GroupLabel from "../../components/molecules/GroupLabel/GroupLabel";
import Header from "../../components/molecules/Header/Header";
import LocationLabel from "../../components/molecules/LocationLabel/LocationLabel";
import Hero from "../../components/organisms/Hero/Hero";
import { Box, ThemeProvider, createTheme } from '@mui/system';

import {
  Typography,
  AppBar,
  CssBaseline,
  Toolbar,
  Container,
  Grid,
  Fab,
} from "@mui/material";
import { Typography, CssBaseline, Container, Fab } from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import { Avatar } from "@mui/material";

const Home = (props) => {
  const name = "Achsaf";
  return (
    <div>
      <p></p>
      <p></p>

      <CssBaseline />
      <Container maxWidth="md">
        <div>
          <Typography
            variant="h3"
            align="center"
            color="textPrimary"
            fontFamily={"Montserrat"}
            fontWeight="700"
            gutterBottom
          >
            Welcome {name}!
          </Typography>
          <Typography
            variant="h6"
            align="center"
            color="textSecondary"
            fontFamily={"Montserrat"}
            fontWeight="400"
            paragraph
          >
            What would you like to study today?
            <p></p>
            <img src={"stinder.jpeg"} width={200} height={300} />
            <p></p>
            <Fab
              style={{ backgroundColor: "#F86459" }}
              //   color="secondary"
              aria-label="add"
              size="medium"
              onClick={() => props.action()}
            >
              <AddIcon />
            </Fab>
          </Typography>
          <Fab color="primary" aria-label="add" sz = {{zIndex: 'tooltip'}}>
            <AddIcon />
          </Fab>
        </div>
      </Container>
    </div>
  );
};

export default Home;
